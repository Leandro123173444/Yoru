package com.aurora.music.ui.screens.settings

import com.aurora.music.localization.appString
import com.aurora.music.R

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import com.aurora.music.ui.theme.TextButton
import com.aurora.music.ui.theme.Button
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.music.data.ArtistSeparator
import com.aurora.music.data.ArtistSeparators
import com.aurora.music.data.SeparatorMatch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import com.aurora.music.data.label

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ArtistSeparatorsScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    val store = com.aurora.music.desktop.ui.LocalDesktopContainer.current.settingsStore
    val saved by store.artistSeparators.collectAsStateWithLifecycle(initialValue = null)
    var draft by remember { mutableStateOf<ArtistSeparators?>(null) }
    var example by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var newText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(saved) { if (draft == null) draft = saved }
    val rules = draft?.rules.orEmpty()
    Column(Modifier.fillMaxWidth()) {
        SettingsTopBar(appString(R.string.text_artist_separators_4a3dc4), onBack)
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = contentPadding.calculateBottomPadding() + 24.dp)) {
            item {
                Text(appString(R.string.text_artist_indexing_and_scrobbling_file_tags_stay_unchanged_def5b6), modifier = Modifier.padding(20.dp),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    OutlinedTextField(example, { example = it.take(500) }, label = { Text(appString(R.string.text_preview_artist_tag_ed9b03)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    SettingsReveal(example.isNotBlank()) {
                        Text(draft?.split(example)?.joinToString(" · ").orEmpty(), Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            itemsIndexed(rules) { index, rule ->
                Spacer(Modifier.height(8.dp))
                SettingsGroup {
                    SegmentedRow(rule.text.orEmpty(), SeparatorMatch.entries.map { it.label },
                        SeparatorMatch.entries.indexOf(rule.match), onSelect = { chosen ->
                            if (!busy) draft = ArtistSeparators(rules.toMutableList().apply { set(index, rule.copy(match = SeparatorMatch.entries[chosen])) })
                        })
                    if (rule.text !in ArtistSeparators.defaults().map { it.text }) {
                        TextButton(enabled = !busy, onClick = { draft = ArtistSeparators(rules.filterIndexed { i, _ -> i != index }) },
                            modifier = Modifier.padding(horizontal = 8.dp)) { Text(appString(R.string.text_remove_separator_8580c6)) }
                    }
                }
            }
            item {
                FlowRow(Modifier.padding(horizontal = 12.dp)) {
                    TextButton(enabled = !busy && draft != null && rules.size < 24, onClick = { adding = true; newText = ""; error = null }) { Text(appString(R.string.text_add_separator_230f65)) }
                    TextButton(enabled = !busy && draft != null, onClick = { draft = ArtistSeparators(); error = null }) { Text(appString(R.string.text_reset_defaults_7871b3)) }
                }
            }
            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    SettingsReveal(error != null) { Text(error.orEmpty(), Modifier.padding(bottom = 8.dp), color = MaterialTheme.colorScheme.error) }
                    Button(enabled = !busy && draft != null && draft != saved, onClick = {
                        scope.launch {
                            busy = true; error = null
                            try { store.setArtistSeparators(requireNotNull(draft)) }
                            catch (cancelled: CancellationException) { throw cancelled }
                            catch (failure: Exception) { error = failure.message ?: appString(R.string.text_could_not_save_separators_e5045b) }
                            finally { busy = false }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) appString(R.string.text_saving_56a228) else appString(R.string.text_save_efc007)) }
                }
            }
        }
    }
    if (adding) AlertDialog(containerColor = com.aurora.music.ui.theme.solidColors().surfaceContainerHigh, onDismissRequest = { adding = false },
        title = { Text(appString(R.string.text_add_separator_230f65), maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = { OutlinedTextField(newText, { newText = it.take(32) }, label = { Text(appString(R.string.text_separator_b4b289)) }, singleLine = true) },
        confirmButton = { TextButton(enabled = newText.isNotBlank() && rules.none { it.text.equals(newText.trim(), true) }, onClick = {
            draft = ArtistSeparators(rules + ArtistSeparator(newText.trim(), SeparatorMatch.SPACED)); adding = false
        }) { Text(appString(R.string.text_add_61cc55)) } }, dismissButton = { TextButton(onClick = { adding = false }) { Text(appString(R.string.text_cancel_77dfd2)) } })
}
