package com.aurora.music.ui.screens.podcasts

import com.aurora.music.localization.appString
import com.aurora.music.ui.theme.paperClip
import com.aurora.music.R

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurora.music.data.Podcast
import com.aurora.music.ui.components.Artwork
import com.aurora.music.util.accentFor
import com.aurora.music.viewmodel.PodcastViewModel
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import com.aurora.music.ui.components.EmptyState
import com.aurora.music.ui.components.LoadingState

private val SEED_TERMS: List<String> get() = listOf(
    appString(R.string.text_news_34c808), appString(R.string.text_comedy_11381a), appString(R.string.text_technology_d018b0), appString(R.string.text_science_d2d066), appString(R.string.text_true_crime_7a3f06),
    appString(R.string.text_history_90ccd6), appString(R.string.text_business_d6663d), appString(R.string.text_sports_2fec45), appString(R.string.text_health_3703cd), appString(R.string.text_music_131260),
)

@Composable
fun PodcastsScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpenPodcast: (Podcast) -> Unit,
) {
    val container = com.aurora.music.desktop.ui.LocalDesktopContainer.current
    val vm: PodcastViewModel = viewModel { PodcastViewModel(container) }
    val state by vm.state.collectAsStateWithLifecycle()
    val subs by vm.subscriptions.collectAsStateWithLifecycle()
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    // seed from vm so field stays in sync after popping back from detail
    var searchOpen by remember { mutableStateOf(state.query.isNotBlank()) }
    var query by remember { mutableStateOf(state.query) }

    Column(Modifier.fillMaxSize().padding(top = topInset)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack, appString(R.string.text_back_b52b36),
                modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable(onClick = onBack).pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(appString(R.string.text_podcasts_fd52b4), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(
                if (searchOpen) Icons.Filled.Close else Icons.Filled.Search,
                if (searchOpen) appString(R.string.text_close_search_0906f9) else appString(R.string.text_search_podcasts_758c3a),
                modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable {
                    searchOpen = !searchOpen
                    if (!searchOpen) { query = ""; vm.clearSearch() }
                }.pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
            )
        }

        AnimatedVisibility(visible = searchOpen) {
            TextField(
                value = query,
                onValueChange = { query = it; vm.search(it) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                placeholder = { Text(appString(R.string.text_search_shows_topics_da6b61)) },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.primary) },
                singleLine = true,
                shape = com.aurora.music.ui.theme.paperSquare(RoundedCornerShape(14.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
            )
        }

        val bottom = contentPadding.calculateBottomPadding() + 24.dp
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottom)) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(SEED_TERMS.size) { i ->
                        val term = SEED_TERMS[i]
                        Text(
                            term,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.paperClip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                .clickable { searchOpen = true; query = term; vm.search(term) }
                                .pointerHoverIcon(PointerIcon.Hand)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                        )
                    }
                }
            }

            if (state.query.isBlank() && subs.isNotEmpty()) {
                item { SectionLabel(appString(R.string.text_subscribed_dd1242)) }
                items(subs.size) { i ->
                    val p = subs[i]
                    PodcastRow(p, onClick = { onOpenPodcast(p) })
                }
            }

            if (state.query.isNotBlank()) {
                item { SectionLabel(appString(R.string.text_results_612e12)) }
                if (state.loading) {
                    item { LoadingState() }
                } else if (state.results.isEmpty()) {
                    item {
                        if (state.failed) EmptyState(Icons.Filled.CloudOff, appString(R.string.text_couldn_t_reach_the_directory_f4b567))
                        else EmptyState(Icons.Filled.Podcasts, appString(R.string.text_no_shows_found_2f293b))
                    }
                } else {
                    items(state.results.size) { i ->
                        val p = state.results[i]
                        PodcastRow(p, onClick = { onOpenPodcast(p) })
                    }
                }
            } else if (subs.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Filled.Podcasts, appString(R.string.text_nothing_here_yet_e89225), Modifier.padding(top = 28.dp),
                        subtitle = appString(R.string.text_search_for_a_show_or_pick_a_topic_above_to_get_started_681552),
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 6.dp),
    )
}

@Composable
private fun PodcastRow(podcast: Podcast, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
            .paperClip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).pointerHoverIcon(PointerIcon.Hand).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Artwork(podcast.imageUrl.orEmpty(), accentFor(podcast.feedUrl), Modifier.size(56.dp), corner = 12.dp)
            if (podcast.imageUrl.isNullOrBlank()) Icon(Icons.Filled.Podcasts, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(podcast.displayTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            podcast.author?.takeIf { it.isNotBlank() }?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
