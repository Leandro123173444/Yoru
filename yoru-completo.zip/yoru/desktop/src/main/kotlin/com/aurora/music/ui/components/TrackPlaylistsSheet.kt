package com.aurora.music.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import com.aurora.music.ui.theme.paperClip
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import com.aurora.music.ui.theme.TextButton
import com.aurora.music.ui.theme.Button
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurora.music.R
import com.aurora.music.desktop.ui.LocalDesktopContainer
import com.aurora.music.localization.appString
import com.aurora.music.model.Playlist
import com.aurora.music.model.Song
import com.aurora.music.ui.layout.LocalWindowLayout
import com.aurora.music.ui.theme.Motion
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import com.aurora.music.model.accent
import com.aurora.music.ui.theme.themedCorner

@Composable
internal fun TrackPlaylistsSheet(song: Song, onDismiss: () -> Unit) {
    val repository = LocalDesktopContainer.current.repository
    val editor = remember(song.id, song.playbackSource?.providerId) { repository.playlistEditor(song) }
    val scope = rememberCoroutineScope()
    val requests = remember { Semaphore(4) }
    var playlists by remember(editor) { mutableStateOf<List<Playlist>?>(null) }
    val membership = remember(editor) { mutableStateMapOf<String, Boolean>() }
    val failedReads = remember(editor) { mutableStateMapOf<String, Boolean>() }
    var loadFailed by remember(editor) { mutableStateOf(false) }
    var saveFailed by remember(editor) { mutableStateOf(false) }
    var busy by remember(editor) { mutableStateOf<String?>(null) }
    var retry by remember(editor) { mutableIntStateOf(0) }
    DisposableEffect(editor) { onDispose { editor?.publishChanges() } }
    LaunchedEffect(editor, retry) {
        if (editor == null) return@LaunchedEffect
        playlists = null
        membership.clear()
        failedReads.clear()
        loadFailed = false
        try { playlists = editor.playlists() }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { loadFailed = true }
    }
    val colors = MaterialTheme.colorScheme
    val maxHeight = (LocalWindowLayout.current.heightDp * .86f).dp
    Dialog(onDismissRequest = { if (busy == null) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(shape = com.aurora.music.ui.theme.paperSquare(RoundedCornerShape(themedCorner(28.dp))), color = com.aurora.music.ui.theme.solidColors().surface, tonalElevation = 0.dp,
            modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth().padding(24.dp)) {
        Column(Modifier.fillMaxWidth().heightIn(max = maxHeight).padding(start = 24.dp, end = 24.dp, top = 24.dp)) {
            Text(appString(R.string.track_swipe_playlists), style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(appString(R.string.track_playlists_hint), style = MaterialTheme.typography.bodyMedium,
                color = colors.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
            Row(
                Modifier.fillMaxWidth().paperClip(RoundedCornerShape(themedCorner(20.dp)))
                    .background(Brush.horizontalGradient(listOf(colors.primary.copy(alpha = .13f), colors.surfaceContainerHigh)))
                    .border(1.dp, colors.primary.copy(alpha = .12f), RoundedCornerShape(themedCorner(20.dp)))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(song.artworkUrl, song.accent,
                    Modifier.size(60.dp).shadow(6.dp, RoundedCornerShape(themedCorner(12.dp))), corner = 12.dp)
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(song.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            when {
                editor == null -> EmptyState(Icons.Outlined.CloudOff, appString(R.string.track_playlists_unavailable))
                loadFailed -> EmptyState(Icons.Outlined.ErrorOutline, appString(R.string.track_playlists_load_error),
                    action = appString(R.string.track_swipe_retry), onAction = { retry++ })
                playlists == null -> LoadingState()
                playlists!!.isEmpty() -> EmptyState(Icons.AutoMirrored.Outlined.QueueMusic, appString(R.string.track_playlists_empty))
                else -> {
                    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(appString(R.string.text_your_playlists_df03eb), Modifier.weight(1f),
                            style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(playlists!!.size.toString(), style = MaterialTheme.typography.labelMedium,
                            color = colors.onSurfaceVariant, modifier = Modifier.paperClip(CircleShape)
                                .background(colors.surfaceContainerHigh).padding(horizontal = 10.dp, vertical = 4.dp))
                    }
                    AnimatedVisibility(saveFailed, enter = fadeIn(Motion.enter()) + expandVertically(Motion.enter()), exit = fadeOut(Motion.exit()) + shrinkVertically(Motion.exit())) {
                        Text(appString(R.string.track_playlists_save_error), color = colors.error,
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 10.dp))
                    }
                    LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 380.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 4.dp)) {
                        items(playlists!!, key = { it.id }) { playlist ->
                            var rowRetry by remember { mutableIntStateOf(0) }
                            LaunchedEffect(editor, playlist.id, rowRetry) {
                                if (membership.containsKey(playlist.id)) return@LaunchedEffect
                                failedReads.remove(playlist.id)
                                try { membership[playlist.id] = requests.withPermit { editor.contains(playlist.id) } }
                                catch (e: CancellationException) { throw e }
                                catch (_: Exception) { failedReads[playlist.id] = true }
                            }
                            val included = membership[playlist.id]
                            val failed = failedReads[playlist.id] == true
                            val rowColor by animateColorAsState(
                                if (included == true) colors.primary.copy(alpha = .10f) else colors.surfaceContainerLow,
                                label = "playlistSelectionFill")
                            val borderColor by animateColorAsState(
                                if (included == true) colors.primary.copy(alpha = .45f) else colors.outlineVariant.copy(alpha = .3f),
                                label = "playlistSelectionBorder")
                            val rowShape = RoundedCornerShape(themedCorner(16.dp))
                            Row(Modifier.fillMaxWidth().clip(rowShape).background(rowColor).border(1.dp, borderColor, rowShape)
                                .toggleable(value = included == true,
                                    enabled = included != null && busy == null, role = Role.Checkbox) { checked ->
                                    busy = playlist.id
                                    saveFailed = false
                                    scope.launch {
                                        try {
                                            if (editor.setIncluded(playlist.id, checked)) membership[playlist.id] = checked
                                            else saveFailed = true
                                        } catch (e: CancellationException) { throw e }
                                        catch (_: Exception) { saveFailed = true }
                                        finally { busy = null }
                                    }
                                }.pointerHoverIcon(PointerIcon.Hand).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Artwork(playlist.coverUrl, playlist.accent, Modifier.size(46.dp), corner = 10.dp)
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(playlist.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    if (included != null) Text(appString(if (included) R.string.track_playlists_in_playlist
                                        else R.string.track_playlists_add), style = MaterialTheme.typography.bodySmall,
                                        color = if (included) colors.primary else colors.onSurfaceVariant,
                                        modifier = Modifier.padding(top = 3.dp))
                                }
                                when {
                                    failed -> TextButton(onClick = { rowRetry++ }) { Text(appString(R.string.track_swipe_retry)) }
                                    included == null || busy == playlist.id -> Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                    }
                                    else -> Crossfade(included, label = "playlistSelectionIcon") { checked ->
                                        Box(Modifier.size(30.dp).paperClip(CircleShape)
                                            .background(if (checked) colors.primary else colors.surfaceContainerHigh),
                                            contentAlignment = Alignment.Center) {
                                            Icon(if (checked) Icons.Default.Check else Icons.Default.Add, null, Modifier.size(18.dp),
                                                tint = if (checked) colors.onPrimary else colors.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Button(onClick = onDismiss, enabled = busy == null, shape = com.aurora.music.ui.theme.paperSquare(RoundedCornerShape(themedCorner(16.dp))),
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 20.dp).heightIn(min = 50.dp)) {
                Text(appString(R.string.track_swipe_done), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            }
        }
        }
    }
}
