package com.aurora.music.ui.screens.settings

import com.aurora.music.localization.appString
import com.aurora.music.ui.theme.paperClip
import com.aurora.music.R

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TextFields
import com.aurora.music.navigation.Routes
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import com.aurora.music.ui.theme.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.music.data.AccentMode
import com.aurora.music.data.AppTypeface
import com.aurora.music.data.CornerStyle
import com.aurora.music.data.HomeSection
import com.aurora.music.data.SeekStyle
import com.aurora.music.data.ThemeMode
import com.aurora.music.data.TabletSetting
import com.aurora.music.data.ThemeStyle
import com.aurora.music.data.UiPrefs
import com.aurora.music.desktop.platform.HostPlatform
import com.aurora.music.desktop.ui.LocalBackdropAvailable
import com.aurora.music.desktop.ui.LocalDesktopContainer
import com.aurora.music.ui.theme.AccentPresets
import com.aurora.music.ui.theme.GlassLook
import com.aurora.music.ui.theme.LocalUiPrefs
import com.aurora.music.ui.theme.ThemeIdentities
import com.aurora.music.ui.theme.ThemeIdentity
import com.aurora.music.ui.theme.accentSeed
import com.aurora.music.ui.theme.auroraBackdrop
import com.aurora.music.ui.theme.auroraPanel
import com.aurora.music.ui.theme.auroraShapes
import com.aurora.music.ui.theme.auroraFontFamily
import com.aurora.music.ui.theme.auroraTypography
import com.aurora.music.ui.theme.styleColorScheme
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import com.aurora.music.ui.theme.Motion
import com.aurora.music.ui.theme.PressScaleIndication
import com.aurora.music.ui.theme.pressClickable
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun AppearanceScreen(contentPadding: PaddingValues, onBack: () -> Unit, page: String = Routes.SETTINGS_APPEARANCE, onOpen: (String) -> Unit = {}) {
    val desktopSettings = LocalDesktopContainer.current.desktopSettings
    val store = LocalDesktopContainer.current.settingsStore
    val prefs by store.uiPrefs.collectAsStateWithLifecycle(initialValue = com.aurora.music.ui.theme.LocalUiPrefs.current)
    val followPlaying by desktopSettings.accentFollowsPlaying.collectAsStateWithLifecycle(initialValue = false)
    val translucentWindow by desktopSettings.translucentWindow.collectAsStateWithLifecycle(initialValue = true)
    val backdropAvailable = LocalBackdropAvailable.current
    val micaBackdrop by desktopSettings.micaBackdrop.collectAsStateWithLifecycle(initialValue = false)
    val systemTitleBar by desktopSettings.systemTitleBar.collectAsStateWithLifecycle(initialValue = false)
    val glassLook by desktopSettings.glassLook.collectAsStateWithLifecycle(initialValue = GlassLook())
    val scope = rememberCoroutineScope()
    fun tablet(setting: TabletSetting, value: Float) { scope.launch { store.setTabletSetting(setting, value) } }

    Column(Modifier.fillMaxWidth()) {
        SettingsTopBar(appString(when (page) {
            Routes.SETTINGS_APPEARANCE_THEMES -> R.string.appearance_themes
            Routes.SETTINGS_APPEARANCE_LAYOUTS -> R.string.appearance_layouts
            Routes.SETTINGS_APPEARANCE_TEXT -> R.string.appearance_text
            Routes.SETTINGS_APPEARANCE_PLAYER -> R.string.text_player_e53407
            Routes.SETTINGS_APPEARANCE_HOME -> R.string.appearance_home_library
            else -> R.string.text_appearance_41def7
        }), onBack)
        SettingsList(contentPadding) {
            when (page) {
                Routes.SETTINGS_APPEARANCE_THEMES -> {
                    item { SettingsSectionTitle(appString(R.string.text_theme_a797e3)) }
                    item { ThemeStylePicker(prefs) { style -> scope.launch { store.setThemeStyle(style) } } }
                    // paper is the website's light edition, so it has no mode to pick
                    item {
                        SettingsReveal(prefs.themeStyle != ThemeStyle.PAPER) {
                            SegmentedRow(appString(R.string.text_mode_a7b93d), listOf(appString(R.string.text_system_bc0792), appString(R.string.text_light_a36ef8), appString(R.string.text_dark_ae1ef0), "AMOLED"), prefs.themeMode) { i ->
                                scope.launch { store.setThemeMode(i) }
                            }
                        }
                    }
                    item {
                        Text(
                            if (prefs.themeStyle == ThemeStyle.PAPER) appString(R.string.theme_paper_light_only) else when (prefs.themeMode) {
                                ThemeMode.AMOLED -> appString(R.string.text_true_black_surfaces_saves_power_on_oled_screens_2481a8)
                                ThemeMode.SYSTEM -> appString(R.string.text_follows_your_device_s_light_dark_setting_38c955)
                                else -> ""
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }

                    // paper stays flat and opaque like the site, so the window glass settings go with the mode picker
                    val glassSettings = backdropAvailable && prefs.themeStyle != ThemeStyle.PAPER
                    if (glassSettings) item {
                        SettingsSwitchRow(
                            title = appString(R.string.text_translucent_window_d865c7),
                            subtitle = appString(R.string.text_let_your_desktop_show_through_the_window_blurred_windows_11_only_08f192),
                            checked = translucentWindow,
                        ) { v -> scope.launch { desktopSettings.setTranslucentWindow(v) } }
                    }
                    item {
                        SettingsReveal(glassSettings && translucentWindow) {
                            SegmentedRow(appString(R.string.text_backdrop_d4f5e9),
                                listOf(appString(R.string.text_acrylic_f39ce1), appString(R.string.text_mica_3ccf84)), if (micaBackdrop) 1 else 0) { i ->
                                scope.launch { desktopSettings.setMicaBackdrop(i == 1) }
                            }
                            SettingsSliderRow(appString(R.string.text_background_tint_a39a12), "${(glassLook.tint / 0.8f * 100).roundToInt()}%",
                                glassLook.tint, 0f..0.8f) { v -> scope.launch { desktopSettings.setGlassTint(v) } }
                            SettingsSliderRow(appString(R.string.text_panel_frost_ada0d3), "${(glassLook.frost / 0.3f * 100).roundToInt()}%",
                                glassLook.frost, 0f..0.3f) { v -> scope.launch { desktopSettings.setGlassFrost(v) } }
                            SettingsSwitchRow(title = appString(R.string.text_glass_edges_f462cd), checked = glassLook.edges) { v ->
                                scope.launch { desktopSettings.setGlassEdges(v) }
                            }
                        }
                    }

                    item {
                        SettingsSwitchRow(
                            title = appString(R.string.window_system_title_bar),
                            subtitle = appString(R.string.window_system_title_bar_summary),
                            checked = systemTitleBar,
                        ) { v -> scope.launch { desktopSettings.setSystemTitleBar(v) } }
                    }
                    if (prefs.themeStyle == ThemeStyle.AURORA || prefs.themeStyle == ThemeStyle.GLASS) {
                    item { SettingsSectionTitle(appString(R.string.text_accent_233064)) }
                    item {
                        SegmentedRow(appString(R.string.text_source_6da13a), listOf(appString(R.string.text_presets_e709e7), appString(R.string.text_custom_081ae3), appString(R.string.text_system_bc0792)), prefs.accentMode) { i ->
                            scope.launch { store.setAccentMode(i) }
                        }
                    }
                    item {
                        SettingsSwitchRow(
                            title = appString(R.string.text_follow_the_playing_cover_5d2e91),
                            subtitle = appString(R.string.text_tint_the_whole_app_with_the_playing_song_s_cover_a83c17),
                            checked = followPlaying,
                        ) { v -> scope.launch { desktopSettings.setAccentFollowsPlaying(v) } }
                    }

                    item {
                        val settled = rememberSettled()
                        AnimatedContent(
                            prefs.accentMode,
                            transitionSpec = {
                                if (settled) fadeIn(Motion.enter()) togetherWith fadeOut(Motion.exit()) using SizeTransform { _, _ -> Motion.enter() }
                                else EnterTransition.None togetherWith ExitTransition.None using null
                            },
                            label = "accentMode",
                        ) { mode ->
                            when (mode) {
                                AccentMode.PRESET -> AccentPresetGrid(selected = prefs.accentPreset) { i -> scope.launch { store.setAccentPreset(i) } }
                                AccentMode.CUSTOM -> CustomColorPicker(initialArgb = prefs.accentColor.toInt()) { argb ->
                                    scope.launch { store.setAccentColor(argb.toLong() and 0xFFFFFFFFL) }
                                }
                                else -> Text(
                                    appString(if (HostPlatform.isWindows) R.string.text_using_your_windows_accent_colour_7d4b4a else R.string.text_using_your_system_accent_colour_89502e),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                                )
                            }
                        }
                    }
                    }
                    if (prefs.themeStyle == ThemeStyle.AURORA) item {
                        SegmentedRow(appString(R.string.text_corners_f1fb13), listOf(appString(R.string.text_sharp_cf3e9a), appString(R.string.text_default_808d7d), appString(R.string.text_rounded_c5aa34), appString(R.string.text_pill_38ea5b)), prefs.cornerStyle) { i ->
                            scope.launch { store.setCornerStyle(i) }
                        }
                    }
                }
                Routes.SETTINGS_APPEARANCE_LAYOUTS -> {
                    item {
                        SegmentedRow(appString(R.string.appearance_home_library), listOf(appString(R.string.layout_classic), appString(R.string.layout_spotlight), appString(R.string.layout_console), appString(R.string.layout_drift)), prefs.pageLayout) { i ->
                            scope.launch { store.setPageLayout(i) }
                        }
                    }
                    item {
                        Text(appString(R.string.layout_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp))
                    }
                    item {
                        Box(Modifier.alpha(if (prefs.barsMatchLayout) 0.55f else 1f)) {
                            SegmentedRow(appString(R.string.bars_title), listOf(appString(R.string.layout_classic), appString(R.string.layout_spotlight), appString(R.string.layout_console), appString(R.string.layout_drift)), prefs.bars) { i ->
                                scope.launch { store.setBarStyle(i) }
                            }
                        }
                    }
                    item {
                        Text(appString(R.string.bars_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp))
                    }
                    item {
                        SegmentedRow(appString(R.string.text_player_e53407), listOf(appString(R.string.layout_classic), appString(R.string.layout_spotlight), appString(R.string.layout_console), appString(R.string.layout_drift)), prefs.playerStyle) { i ->
                            scope.launch { store.setPlayerStyle(i) }
                        }
                    }
                    item {
                        SettingsSwitchRow(title = appString(R.string.bars_match_title), subtitle = appString(R.string.bars_match_hint), checked = prefs.barsMatchLayout) { v ->
                            scope.launch { store.setBarsMatchLayout(v) }
                        }
                    }
                    item {
                        SettingsSwitchRow(title = appString(R.string.search_own_title), subtitle = appString(R.string.search_own_hint), checked = prefs.searchOwnLayout) { v ->
                            scope.launch { store.setSearchOwnLayout(v) }
                        }
                    }
                    item {
                        SettingsReveal(prefs.searchOwnLayout) {
                            SegmentedRow(appString(R.string.text_search_bce064), listOf(appString(R.string.layout_classic), appString(R.string.layout_spotlight), appString(R.string.layout_console), appString(R.string.layout_drift)), prefs.searchStyle) { i ->
                                scope.launch { store.setSearchStyle(i) }
                            }
                        }
                    }
                    item { SettingsSectionTitle(appString(R.string.tablet_layout_title)) }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_dock_size), "${(prefs.tabletDockScale * 100).roundToInt()}%",
                            prefs.tabletDockScale, TabletSetting.DOCK.range) { tablet(TabletSetting.DOCK, it) }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_panel_controls), "${(prefs.tabletPanelScale * 100).roundToInt()}%",
                            prefs.tabletPanelScale, TabletSetting.PANEL.range) { tablet(TabletSetting.PANEL, it) }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_panel_spacing), "${prefs.tabletPanelSpacing.roundToInt()} dp",
                            prefs.tabletPanelSpacing, TabletSetting.PANEL_SPACING.range) { tablet(TabletSetting.PANEL_SPACING, it) }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_nav_gap), "${prefs.tabletNavGap.roundToInt()} dp",
                            prefs.tabletNavGap, TabletSetting.NAV_GAP.range) { tablet(TabletSetting.NAV_GAP, it) }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_page_margins), "${prefs.tabletPageMargin.roundToInt()} dp",
                            prefs.tabletPageMargin, TabletSetting.PAGE_MARGIN.range) { tablet(TabletSetting.PAGE_MARGIN, it) }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_hero_size), "${(prefs.tabletHeroScale * 100).roundToInt()}%",
                            prefs.tabletHeroScale, TabletSetting.HERO.range) { tablet(TabletSetting.HERO, it) }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.tablet_favourites_size), "${(prefs.tabletFavouriteScale * 100).roundToInt()}%",
                            prefs.tabletFavouriteScale, TabletSetting.FAVOURITE.range) { tablet(TabletSetting.FAVOURITE, it) }
                    }
                    item {
                        val left = (prefs.tabletPlayerSplit * 100).roundToInt()
                        SettingsSliderRow(appString(R.string.tablet_player_split), "$left / ${100 - left}",
                            prefs.tabletPlayerSplit, TabletSetting.PLAYER_SPLIT.range) { tablet(TabletSetting.PLAYER_SPLIT, it) }
                    }
                    item {
                        Text(appString(R.string.tablet_player_split_hint), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp))
                    }
                    item {
                        TextButton(onClick = { scope.launch { store.resetTabletSettings() } },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp).pointerHoverIcon(PointerIcon.Hand)) {
                            Text(appString(R.string.tablet_reset))
                        }
                    }
                }
                Routes.SETTINGS_APPEARANCE_TEXT -> {
                    item {
                        TypefacePicker(prefs) { typeface -> scope.launch { store.setTypeface(typeface) } }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.text_font_size_83ca9e), "${(prefs.fontScale * 100).roundToInt()}%", prefs.fontScale, 0.85f..1.3f) { v ->
                            scope.launch { store.setFontScale(v) }
                        }
                    }
                }
                Routes.SETTINGS_APPEARANCE_PLAYER -> {
                    item { SettingsSectionTitle(appString(R.string.text_player_e53407)) }
                    item {
                        SegmentedRow(appString(R.string.text_seek_bar_0030d0), listOf(appString(R.string.text_waveform_200f14), appString(R.string.text_bar_e496fd)), prefs.playerSeekStyle) { i ->
                            scope.launch { store.setPlayerSeekStyle(i) }
                        }
                    }
                    item {
                        SettingsReveal(prefs.playerSeekStyle == SeekStyle.WAVEFORM) {
                            SettingsSliderRow(appString(R.string.text_waveform_bars_c215c9), "${prefs.playerWaveBars}", prefs.playerWaveBars.toFloat(), 24f..96f) { v ->
                                scope.launch { store.setPlayerWaveBars(v.roundToInt()) }
                            }
                        }
                    }
                    item {
                        SettingsSliderRow(appString(R.string.text_artwork_size_6dd0fc), "${(prefs.playerArtSize * 100).roundToInt()}%", prefs.playerArtSize, 0.6f..1f) { v ->
                            scope.launch { store.setPlayerArtSize(v) }
                        }
                    }
                    if (prefs.themeStyle == ThemeStyle.AURORA) item {
                        SettingsSliderRow(appString(R.string.text_gradient_intensity_84a1f5), "${(prefs.playerGradient * 100).roundToInt()}%", prefs.playerGradient, 0f..1.5f) { v ->
                            scope.launch { store.setPlayerGradient(v) }
                        }
                    }
                    item {
                        SettingsSwitchRow(title = appString(R.string.text_bottom_utilities_8b97ef), subtitle = appString(R.string.text_speed_lyrics_queue_row_814225), checked = prefs.playerShowUtilities) { v ->
                            scope.launch { store.setPlayerShowUtilities(v) }
                        }
                    }
                    item { SettingsSectionTitle(appString(R.string.text_miniplayer_4adff2)) }
                    item {
                        SegmentedRow(appString(R.string.text_style_99a0ef), listOf(appString(R.string.text_standard_2dfa66), appString(R.string.text_compact_1df39a), appString(R.string.text_prominent_4b3579)), prefs.miniStyle) { i ->
                            scope.launch { store.setMiniStyle(i) }
                        }
                    }
                    item {
                        SegmentedRow(appString(R.string.text_progress_1b9027), listOf(appString(R.string.text_line_ea9676), appString(R.string.text_bar_e496fd), appString(R.string.text_none_6eef66)), prefs.miniProgress) { i ->
                            scope.launch { store.setMiniProgress(i) }
                        }
                    }
                }
                Routes.SETTINGS_APPEARANCE_HOME -> {
                    item { SettingsSectionTitle(appString(R.string.text_library_b8100f)) }
                    item {
                        SegmentedRow(appString(R.string.text_grid_columns_b0c94c), listOf("2", "3", "4"), (prefs.libraryColumns - 2).coerceIn(0, 2)) { i ->
                            scope.launch { store.setLibraryColumns(i + 2) }
                        }
                    }
                    item { SettingsSectionTitle(appString(R.string.text_home_sections_1f24fb)) }
                    val mixSections = listOf(HomeSection.MIXES to appString(R.string.foryou_title)) + if (HomeSection.MIXES in prefs.hiddenHomeSections) emptyList() else listOf(
                        HomeSection.MIX_TIME to appString(R.string.foryou_setting_time),
                        HomeSection.MIX_DAILY to appString(R.string.foryou_setting_daily),
                        HomeSection.MIX_RECOMMENDED to appString(R.string.foryou_recommended),
                        HomeSection.MIX_DISCOVER to appString(R.string.foryou_discover),
                        HomeSection.MIX_STATIONS to appString(R.string.foryou_stations),
                    )
                    val homeSections = mixSections + listOf(
                        HomeSection.HERO to appString(R.string.text_new_release_hero_c354b3),
                        HomeSection.RECENT to appString(R.string.text_jump_back_in_1d9181),
                        HomeSection.PLAYLISTS to appString(R.string.text_your_playlists_df03eb),
                        HomeSection.FAVOURITE to appString(R.string.text_from_your_favourites_d39722),
                        HomeSection.MOST to appString(R.string.text_most_played_14202e),
                        HomeSection.ARTISTS to appString(R.string.text_artists_1528d8),
                        HomeSection.NEW to appString(R.string.text_new_releases_3cdd02),
                        HomeSection.RECOMMENDED to appString(R.string.text_recommended_albums_36271e),
                    )
                    items(homeSections.size) { idx ->
                        val (id, label) = homeSections[idx]
                        SettingsSwitchRow(title = label, checked = id !in prefs.hiddenHomeSections) { v ->
                            scope.launch { store.setHomeSectionHidden(id, !v) }
                        }
                    }
                }
                else -> item {
                    SettingsGroup {
                        SettingsNavRow(Icons.Filled.Palette, appString(R.string.appearance_themes), subtitle = appString(R.string.appearance_themes_summary)) { onOpen(Routes.SETTINGS_APPEARANCE_THEMES) }
                        SettingsRowDivider()
                        SettingsNavRow(Icons.Filled.Dashboard, appString(R.string.appearance_layouts), subtitle = appString(R.string.appearance_layouts_summary)) { onOpen(Routes.SETTINGS_APPEARANCE_LAYOUTS) }
                        SettingsRowDivider()
                        SettingsNavRow(Icons.Filled.TextFields, appString(R.string.appearance_text), subtitle = appString(R.string.appearance_text_summary)) { onOpen(Routes.SETTINGS_APPEARANCE_TEXT) }
                        SettingsRowDivider()
                        SettingsNavRow(Icons.Filled.MusicNote, appString(R.string.text_player_e53407), subtitle = appString(R.string.appearance_player_summary)) { onOpen(Routes.SETTINGS_APPEARANCE_PLAYER) }
                        SettingsRowDivider()
                        SettingsNavRow(Icons.Filled.Home, appString(R.string.appearance_home_library), subtitle = appString(R.string.appearance_home_library_summary)) { onOpen(Routes.SETTINGS_APPEARANCE_HOME) }
                        SettingsRowDivider()
                        SettingsNavRow(Icons.Filled.Menu, appString(R.string.nav_menu_title), subtitle = appString(R.string.nav_menu_summary)) { onOpen(Routes.SETTINGS_NAV_MENU) }
                    }
                }
            }
        }
    }
}

@Composable
private fun TypefacePicker(prefs: UiPrefs, onSelect: (Int) -> Unit) {
    Text(
        appString(R.string.typeface_title),
        style = MaterialTheme.typography.titleSmall,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
    )
    val options = listOf(
        AppTypeface.THEME_DEFAULT to appString(R.string.typeface_theme_default),
        AppTypeface.DM_SANS to "DM Sans",
        AppTypeface.PLUS_JAKARTA_SANS to "Plus Jakarta Sans",
        AppTypeface.MANROPE to "Manrope",
    )
    SettingsGroup {
        Column(Modifier.selectableGroup()) {
            options.forEach { (typeface, label) ->
                val selected = prefs.typeface == typeface
                val family = auroraFontFamily(typeface, prefs.themeStyle)
                Row(
                    Modifier.fillMaxWidth()
                        .pointerHoverIcon(PointerIcon.Hand)
                        .selectable(selected = selected, role = Role.RadioButton, onClick = { onSelect(typeface) })
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(label, style = MaterialTheme.typography.titleMedium, fontFamily = family, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            appString(R.string.typeface_preview),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = family,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    RadioButton(selected = selected, onClick = null)
                }
            }
        }
    }
}

@Composable
private fun ThemeStylePicker(prefs: UiPrefs, onSelect: (Int) -> Unit) {
    val dark = MaterialTheme.colorScheme.onBackground.luminance() > 0.5f
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ThemeIdentities.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { identity ->
                    val selected = identity.id == prefs.themeStyle
                    val frameWidth by animateDpAsState(if (selected) 2.dp else 1.dp, Motion.state(), label = "themeFrameWidth")
                    val frame by animateColorAsState(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, Motion.state(), label = "themeFrame")
                    Column(
                        Modifier.weight(1f)
                            .clip(MaterialTheme.shapes.medium)
                            .background(MaterialTheme.colorScheme.surface)
                            .border(frameWidth, frame, MaterialTheme.shapes.medium)
                            .pointerHoverIcon(PointerIcon.Hand)
                            .selectable(selected = selected, interactionSource = null, indication = PressScaleIndication, role = Role.RadioButton, onClick = { onSelect(identity.id) })
                            .padding(4.dp),
                    ) {
                        ThemePreview(identity, prefs, dark)
                        Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 6.dp, top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(identity.name, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            AnimatedVisibility(selected, enter = fadeIn(Motion.state()) + scaleIn(Motion.state()), exit = fadeOut(Motion.state()) + scaleOut(Motion.state())) {
                                Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
        val current = ThemeIdentities.firstOrNull { it.id == prefs.themeStyle } ?: ThemeIdentities.first()
        Text(current.description, style = MaterialTheme.typography.titleSmall)
        Text(current.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (prefs.themeStyle != ThemeStyle.AURORA && prefs.themeStyle != ThemeStyle.GLASS) {
            Text(appString(R.string.text_this_style_includes_its_own_colors_and_corners_your_aurora_custom_9b4b82), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ThemePreview(identity: ThemeIdentity, prefs: UiPrefs, dark: Boolean) {
    CompositionLocalProvider(LocalUiPrefs provides prefs.copy(themeStyle = identity.id)) {
        MaterialTheme(
            colorScheme = styleColorScheme(identity.id, dark, if (identity.id == ThemeStyle.GLASS) prefs.accentSeed(null) else null),
            typography = auroraTypography(0.85f, identity.id, prefs.typeface),
            shapes = auroraShapes(CornerStyle.DEFAULT, identity.id),
        ) {
            Column(Modifier.fillMaxWidth().height(122.dp).clip(MaterialTheme.shapes.small).auroraBackdrop().padding(10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("AURORA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(MaterialTheme.shapes.extraSmall).background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary))), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(22.dp).border(4.dp, MaterialTheme.colorScheme.background.copy(alpha = 0.55f), CircleShape))
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.fillMaxWidth(0.95f).height(4.dp).background(MaterialTheme.colorScheme.onBackground))
                        Box(Modifier.fillMaxWidth(0.65f).height(3.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)))
                    }
                }
                Row(Modifier.fillMaxWidth().height(26.dp).auroraPanel(MaterialTheme.shapes.small, emphasized = true).padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(0.25f, 0.55f, 0.85f, 0.5f, 0.7f, 0.35f, 0.6f, 0.4f).forEach { level ->
                        Box(Modifier.weight(1f).height((level * 18).dp).background(MaterialTheme.colorScheme.primary))
                    }
                }
            }
        }
    }
}

@Composable
private fun AccentPresetGrid(selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AccentPresets.chunked(5).forEachIndexed { rowIdx, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEachIndexed { colIdx, preset ->
                    val index = rowIdx * 5 + colIdx
                    val isSel = index == selected
                    val ring by animateColorAsState(MaterialTheme.colorScheme.onBackground.copy(alpha = if (isSel) 1f else 0f), Motion.state(), label = "accentRing")
                    Box(
                        Modifier.weight(1f).height(56.dp).paperClip(RoundedCornerShape(16.dp))
                            .background(preset.seed)
                            .border(3.dp, ring, com.aurora.music.ui.theme.paperSquare(RoundedCornerShape(16.dp)))
                            .pointerHoverIcon(PointerIcon.Hand)
                            .pressClickable { onSelect(index) },
                        contentAlignment = Alignment.Center,
                    ) {
                        androidx.compose.animation.AnimatedVisibility(isSel, enter = fadeIn(Motion.state()) + scaleIn(Motion.state()), exit = fadeOut(Motion.state()) + scaleOut(Motion.state())) {
                            val on = if (preset.seed.luminanceApprox() > 0.5f) Color.Black else Color.White
                            Icon(Icons.Filled.Check, appString(R.string.text_selected_9a976f), tint = on, modifier = Modifier.size(22.dp))
                        }
                    }
                }
                // pad the short final row so swatches keep their width
                repeat(5 - row.size) { Box(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun CustomColorPicker(initialArgb: Int, onChange: (Int) -> Unit) {
    val initialHsb = remember {
        java.awt.Color.RGBtoHSB(initialArgb shr 16 and 0xFF, initialArgb shr 8 and 0xFF, initialArgb and 0xFF, null)
    }
    var hue by remember { mutableFloatStateOf(initialHsb[0] * 360f) }
    var sat by remember { mutableFloatStateOf(initialHsb[1]) }
    var bri by remember { mutableFloatStateOf(initialHsb[2]) }

    fun argb() = java.awt.Color.HSBtoRGB(hue / 360f, sat, bri) or (0xFF shl 24)
    // the preview follows every move; only the stored accent is throttled, and the release writes at once
    val live = rememberLiveValue(initialArgb) { onChange(it) }
    fun push() = live.set(argb())
    val flush: () -> Unit = { live.pending.value?.let { live.pending.value = null; onChange(it) } }
    val preview = Color(argb())

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(56.dp).paperClip(CircleShape).background(preview).border(2.dp, MaterialTheme.colorScheme.outline, com.aurora.music.ui.theme.paperSquare(CircleShape)))
            Text(appString(R.string.text_live_preview_d44c24), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DirectSliderRow(appString(R.string.text_hue_7e58a6), "${hue.roundToInt()}°", hue, 0f..360f, onValueChangeFinished = flush) { hue = it; push() }
        DirectSliderRow(appString(R.string.text_saturation_20a32b), "${(sat * 100).roundToInt()}%", sat, 0f..1f, onValueChangeFinished = flush) { sat = it; push() }
        DirectSliderRow(appString(R.string.text_brightness_e1a2b6), "${(bri * 100).roundToInt()}%", bri, 0f..1f, onValueChangeFinished = flush) { bri = it; push() }
    }
}

private fun Color.luminanceApprox(): Float = 0.299f * red + 0.587f * green + 0.114f * blue
