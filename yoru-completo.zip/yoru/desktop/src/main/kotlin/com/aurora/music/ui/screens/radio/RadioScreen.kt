package com.aurora.music.ui.screens.radio

import com.aurora.music.localization.appString
import com.aurora.music.ui.theme.paperClip
import com.aurora.music.R

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import com.aurora.music.ui.theme.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurora.music.data.RadioStation
import com.aurora.music.data.toSong
import com.aurora.music.model.Song
import com.aurora.music.ui.components.Artwork
import com.aurora.music.util.accentFor
import com.aurora.music.viewmodel.RadioViewModel
import androidx.compose.animation.animateColorAsState
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import com.aurora.music.ui.components.EmptyState
import com.aurora.music.ui.components.LoadingState
import com.aurora.music.ui.theme.Motion

private val GENRE_TAGS = listOf(
    "pop", "rock", "jazz", "classical", "news", "electronic", "hip hop",
    "country", "metal", "ambient", "lounge", "dance", "reggae", "blues", "talk",
)

@Composable
fun RadioScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onPlay: (Song) -> Unit,
) {
    val container = com.aurora.music.desktop.ui.LocalDesktopContainer.current
    val vm: RadioViewModel = viewModel { RadioViewModel(container) }
    val state by vm.state.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    val playStation: (RadioStation) -> Unit = { st -> vm.registerPlay(st); onPlay(st.toSong()) }
    val favoriteUuids = favorites.mapTo(HashSet()) { it.uuid }
    val browsing = state.query.isBlank() && state.activeTag.isBlank()
    val listed = if (browsing) state.popular else state.results

    Column(Modifier.fillMaxSize().padding(top = topInset)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack, appString(R.string.text_back_b52b36),
                modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable(onClick = onBack).pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(appString(R.string.text_radio_b11bf1), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(
                Icons.Filled.Add, appString(R.string.text_add_custom_stream_638147),
                modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable { showAdd = true }.pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
            )
            Icon(
                if (searchOpen) Icons.Filled.Close else Icons.Filled.Search,
                if (searchOpen) appString(R.string.text_close_search_0906f9) else appString(R.string.text_search_stations_3b38bf),
                modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable {
                    searchOpen = !searchOpen
                    if (!searchOpen) { query = ""; vm.clearSearch() }
                }.pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
            )
        }

        AnimatedVisibility(visible = searchOpen) {
            TextField(
                value = query,
                onValueChange = { query = it; vm.search(it) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                placeholder = { Text(appString(R.string.text_search_radio_stations_be278b)) },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.primary) },
                singleLine = true,
                shape = com.aurora.music.ui.theme.paperSquare(RoundedCornerShape(14.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
            )
        }

        val bottom = contentPadding.calculateBottomPadding() + 24.dp
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottom)) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(GENRE_TAGS.size) { i ->
                        val tag = GENRE_TAGS[i]
                        val selected = state.activeTag == tag
                        val chipInk by animateColorAsState(if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, Motion.state(), label = "tagInk")
                        val chipFill by animateColorAsState(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh, Motion.state(), label = "tagFill")
                        Text(
                            tag.replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = chipInk,
                            modifier = Modifier.paperClip(RoundedCornerShape(50))
                                .background(chipFill)
                                .clickable { if (selected) vm.loadPopular() else vm.byTag(tag) }
                                .pointerHoverIcon(PointerIcon.Hand)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                        )
                    }
                }
            }

            if (favorites.isNotEmpty()) {
                item { SectionLabel(appString(R.string.text_your_stations_d1f54b)) }
                items(favorites.size) { i ->
                    val st = favorites[i]
                    StationRow(st, isFavorite = true, onPlay = { playStation(st) }, onToggleFavorite = { vm.toggleFavorite(st) })
                }
            }

            item {
                SectionLabel(
                    when {
                        state.query.isNotBlank() -> appString(R.string.text_results_612e12)
                        state.activeTag.isNotBlank() -> state.activeTag.replaceFirstChar { it.uppercase() }
                        else -> appString(R.string.text_popular_worldwide_b0f24f)
                    }
                )
            }

            if (state.loading) {
                item { LoadingState() }
            } else if (listed.isEmpty()) {
                item {
                    if (state.failed) EmptyState(Icons.Filled.CloudOff, appString(R.string.text_couldn_t_reach_the_radio_directory_c0321f))
                    else EmptyState(Icons.Filled.Radio, appString(R.string.text_no_stations_found_173164))
                }
            } else {
                items(listed.size) { i ->
                    val st = listed[i]
                    StationRow(st, isFavorite = favoriteUuids.contains(st.uuid), onPlay = { playStation(st) }, onToggleFavorite = { vm.toggleFavorite(st) })
                }
            }
        }
    }

    if (showAdd) {
        AddStreamDialog(
            onAdd = { name, url -> vm.addCustom(name, url); showAdd = false },
            onDismiss = { showAdd = false },
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 6.dp),
    )
}

@Composable
private fun StationRow(
    station: RadioStation,
    isFavorite: Boolean,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
            .paperClip(RoundedCornerShape(16.dp)).clickable(onClick = onPlay).pointerHoverIcon(PointerIcon.Hand).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
            Artwork(station.faviconUrl.orEmpty(), accentFor("radio:${station.uuid}"), Modifier.size(48.dp), corner = 10.dp)
            if (station.faviconUrl.isNullOrBlank()) {
                Icon(Icons.Filled.Radio, null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(station.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val meta = buildList {
                if (station.genre.isNotBlank()) add(station.genre)
                station.codec?.takeIf { it.isNotBlank() }?.let { add(it.uppercase()) }
                station.bitrate?.takeIf { it > 0 }?.let { add("${it}k") }
            }.joinToString(" • ")
            if (meta.isNotBlank()) Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            if (isFavorite) appString(R.string.text_unfavorite_de9bba) else appString(R.string.text_favorite_6b90b6),
            tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable(onClick = onToggleFavorite).pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
        )
        Icon(
            Icons.Filled.PlayArrow, appString(R.string.text_play_5d12bd),
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(40.dp).paperClip(CircleShape).clickable(onClick = onPlay).pointerHoverIcon(PointerIcon.Hand).padding(8.dp),
        )
    }
}

@Composable
private fun AddStreamDialog(onAdd: (String, String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    AlertDialog(containerColor = com.aurora.music.ui.theme.solidColors().surfaceContainerHigh, 
        onDismissRequest = onDismiss,
        title = { Text(appString(R.string.text_add_radio_stream_48fecc), fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(appString(R.string.text_name_optional_9c9f03)) }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text(appString(R.string.text_stream_url_e25c5b)) }, singleLine = true, placeholder = { Text("https://…") })
            }
        },
        confirmButton = { TextButton(onClick = { if (url.isNotBlank()) onAdd(name, url) }, enabled = url.isNotBlank()) { Text(appString(R.string.text_add_61cc55)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(appString(R.string.text_cancel_77dfd2)) } },
    )
}
